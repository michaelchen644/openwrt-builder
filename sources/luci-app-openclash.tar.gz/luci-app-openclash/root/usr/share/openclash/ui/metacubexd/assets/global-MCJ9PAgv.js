import{Y as a}from"./vendor-TCjgV7Sn.js";import{ad as m}from"./index-k-FO5KmN.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
